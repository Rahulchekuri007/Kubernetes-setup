#!/bin/bash
#Setup and Install Kubernetes Master repos and packages

kube_version="1.9.2-00"
kube_release="stable-1.9"
kube_cni="weavenet"
workers_count=1
ubuntu_release=xenial
master_nodes="edalkbmp01.elan.elantecs.com"
worker_nodes="edalkbwp01.elan.elantecs.com edalkbwp02.elan.elantecs.com"
first_worker_node=edalkbwp01

sudo echo "deb http://security.ubuntu.com/ubuntu/ ${ubuntu_release}-updates universe" > /etc/apt/sources.list.d/docker.list
apt-get install apt-transport-https
apt-get update
apt-get install -y docker.io

cat << EOF > /etc/docker/daemon.json
{
  "exec-opts": ["native.cgroupdriver=cgroupfs"]
}
EOF

curl -s https://packages.cloud.google.com/apt/doc/apt-key.gpg | apt-key add -

cat << EOF > /etc/apt/sources.list.d/kubernetes.list
deb http://apt.kubernetes.io/ kubernetes-${ubuntu_release} main
EOF

apt-get update
if [ ${kube_version} = latest ];then
apt-get install -y kubectl kubelet kubeadm
else
apt-get install -y kubectl=${kube_version} kubelet=${kube_version} kubeadm=${kube_version}
fi

swapoff -a
sed -i "/swap/ s/^/#/g" /etc/fstab

#Initialize Kube Master

HOME=/root
if [ ! -d /etc/kubernetes/manifests ];then
if [ ${kube_release} = latest ];then
if [[ ${kube_cni} = flannel ]] || [[ ${kube_cni} = canal ]] || [[ ${kube_cni} = weavenet ]];then
kubeadm init --pod-network-cidr=10.244.0.0/16 | tee /root/kubeadm.init
else
kubeadm init --pod-network-cidr=192.168.0.0/16 | tee /root/kubeadm.init
fi
else
if [[ ${kube_cni} = flannel ]] || [[ ${kube_cni} = canal ]] || [[ ${kube_cni} = weavenet ]];then
kubeadm init --kubernetes-version ${kube_release} --pod-network-cidr=10.244.0.0/16 | tee /root/kubeadm.init
else
kubeadm init --kubernetes-version ${kube_release} --pod-network-cidr=192.168.0.0/16 | tee /root/kubeadm.init
fi
fi
echo $HOME
mkdir -p $HOME/.kube
sudo cp -i /etc/kubernetes/admin.conf $HOME/.kube/config
sudo chown $(id -u):$(id -g) $HOME/.kube/config

#Flannel/Calico/Canal Network Pod
cd $HOME

if [ ${kube_cni} = flannel ];then
kubectl apply -f https://raw.githubusercontent.com/coreos/flannel/v0.9.1/Documentation/kube-flannel.yml | tee /root/flannel.init
elif [ ${kube_cni} = canal ];then
kubectl apply -f https://raw.githubusercontent.com/projectcalico/canal/master/k8s-install/1.7/rbac.yaml | tee /root/canal.init
kubectl apply -f https://raw.githubusercontent.com/projectcalico/canal/master/k8s-install/1.7/canal.yaml | tee /root/canal.init
elif [ ${kube_cni} = weavenet ];then
export kubever=$(kubectl version | base64 | tr -d '\n')
kubectl apply -f "https://cloud.weave.works/k8s/net?k8s-version=$kubever"
else
kubectl apply -f https://docs.projectcalico.org/v3.0/getting-started/kubernetes/installation/hosted/kubeadm/1.7/calico.yaml | tee /root/calico.init
fi
else
echo -e "\nKubernetes Setup already Exists..Skipping Setup..\n"
fi

kubectl get nodes

##############################################################################################
# Install nfs-kernel-server for Kubernetes Storage
mkdir -p /var/tmp/mnt
apt-get install -y nfs-kernel-server

private_nfs_client=$worker_nodes

for j in $private_nfs_client
do
for i in $j
do
grep $i /etc/exports || echo -e "$i(rw,sync,no_subtree_check)" >> /tmp/file.$$
done
done

if [ -s "/tmp/file.$$" ];then
nfs_clients=$(cat /tmp/file.$$ | tr "\n" " ")
echo -e "/var/tmp/mnt\t$nfs_clients" >> /etc/exports
fi

exportfs -ra
rm -rf /tmp/file.$$
##############################################################################################
# Worker Bootstrap and Helm Setup Related Roles Settings
###############################################################################################
# Worker Bootstrap and Helm Setup Related Roles Settings
cd ~
ln -sf /home/awsadmin/.aws /root/.aws
aws s3 cp s3://elanrepo/files/kubernetes/local/id_rsa /root/.ssh
chmod 400 /root/.ssh/id_rsa
for node in $worker_nodes
do
ssh -o StrictHostKeychecking=no $node "[ -f /root/kubeadm-join.int ] || eval $(grep "kubeadm join" /root/kubeadm.init) | tee -a /root/kubeadm-join.int"
done

# sleep 120

cd ~
if [ ! -d "./helmet" ];then 
git clone https://github.com/daemonza/helmet.git
wget https://kubernetes-helm.storage.googleapis.com/helm-v2.8.2-linux-amd64.tar.gz
tar -zxvf helm-v2.8.2-linux-amd64.tar.gz
cp -rp linux-amd64/helm /usr/sbin/
export HELM_HOME="/root/.helm"
helm init | tee -a ~/helmet.init
kubectl create serviceaccount --namespace kube-system tiller 2> /dev/null
kubectl create clusterrolebinding tiller-cluster-rule --clusterrole=cluster-admin --serviceaccount=kube-system:tiller 2>/dev/null
kubectl patch deploy --namespace kube-system tiller-deploy -p '{"spec":{"template":{"spec":{"serviceAccount":"tiller"}}}}' 2>/dev/null
sleep 60
helm package ~/helmet/helmet-chart/ -d ~/helmet/helmet-chart/ --debug | tee -a ~/helmet.init
helm install ~/helmet/helmet-chart/helmet-chart-0.0.1.tgz | tee -a ~/helmet.init
eval $(egrep "NODE_IP=|NODE_PORT=" ~/helmet.init)
sleep 60
sed -i "/cache:/ s/.helm\/repository\/cache\///g" ~/.helm/repository/repositories.yaml
cd ~
helm repo update
helm repo add helmet http://$NODE_IP:$NODE_PORT/charts/
curl -v -T ~/helmet/helmet-chart/helmet-chart-0.0.1.tgz -X PUT http://$NODE_IP:$NODE_PORT/upload/ | tee -a ~/helmet.init
curl http://$NODE_IP:$NODE_PORT/charts/index.yaml | tee -a ~/helmet.init
echo -e "\nPlease Use the below command to query the charts:\n" | tee -a ~/helmet.init
echo -e "\ncurl http://$NODE_IP:$NODE_PORT/charts/index.yaml\n" | tee -a ~/helmet.init
else
echo -e "\nHelm Setup Already Exist..Skipping Setup..\n"
fi
###############################################################################################
#Openssl Certs Setup and Ingress Controller Setup
aws s3 sync s3://elanrepo/files/kubernetes/ /var/tmp/files
cd /var/tmp/files/
tar -zxvf openssl-certs-setup.tar.gz
cd openssl-certs-setup
cp -rp /var/tmp/files/s3_sync_practice.sh /root
cp -rp /var/tmp/files/docker-images-tags /usr/bin
bash regenerate_certs.sh kube-external.elan.elantecs.com
cd ~
kubectl create secret tls tls-certificate --key /var/tmp/files/openssl-certs-setup/privatekey.key --cert /var/tmp/files/openssl-certs-setup/kube-external.elan.elantecs.com.pem -n kube-system 2> /dev/null
kubectl create secret generic tls-dhparam --from-file=/var/tmp/files/openssl-certs-setup/kube-external.elan.elantecs.com-dhparam.pem -n kube-system 2>/dev/null
chmod 700 /var/tmp/files/*.yaml
cp -rp /var/tmp/files/dashboard-setup/*.yaml /etc/kubernetes/manifests/
cp -rp /var/tmp/files/dashboard-setup/local/*.yaml /etc/kubernetes/manifests/
kubectl label nodes $first_worker_node role=nginx-ingress --overwrite
helm install stable/nginx-ingress --name nginx-ingress --set rbac.create=true --set controller.hostNetwork=true --set controller.service.type=ClusterIP --set controller.nodeSelector."role"=nginx-ingress 2>/dev/null
sleep 60
kubectl get pods --all-namespaces -l app=nginx-ingress
POD_NAMESPACE=default
POD_NAME=$(kubectl get pods -n $POD_NAMESPACE -l app=nginx-ingress -o jsonpath={.items[0].metadata.name})
sleep 30
kubectl exec -it $POD_NAME -n $POD_NAMESPACE -- /nginx-ingress-controller --version
################################################################################################

#Kubernetes Dashboard
mkdir -p /var/tmp/files/openssl-certs-setup/dashboard
cp -rp /var/tmp/files/openssl-certs-setup/privatekey.key /var/tmp/files/openssl-certs-setup/dashboard/dashboard.key
cp -rp /var/tmp/files/openssl-certs-setup/kube-external.elan.elantecs.com-onlycert.pem /var/tmp/files/openssl-certs-setup/dashboard/dashboard.crt
kubectl create secret generic kubernetes-dashboard-certs --from-file=/var/tmp/files/openssl-certs-setup/dashboard -n kube-system 2>/dev/null
kubectl create -f /etc/kubernetes/manifests/kubernetes-dashboard.yaml -n kube-system 2>/dev/null
kubectl create -f /etc/kubernetes/manifests/kube-dash-ingress.yaml -n kube-system 2>/dev/null
kubectl apply -f /etc/kubernetes/manifests/kube-dash-clusterrolebinding.yaml -n kube-system 2>/dev/null
rm -rf /root/Please_Be_Patient_Until_Cloud_Init_Finishes_AND_Until_You_See_This_File_Using_ls
#################################################################################################

#Kubernetes Heapster
cd /var/tmp/files
[ ! -d heapster ] && git clone https://github.com/kubernetes/heapster.git
cd ~
kubectl create -f /var/tmp/files/heapster/deploy/kube-config/influxdb/ 2>/dev/null
kubectl create -f /var/tmp/files/heapster/deploy/kube-config/rbac/heapster-rbac.yaml 2>/dev/null
#################################################################################################
unlink /root/.aws
